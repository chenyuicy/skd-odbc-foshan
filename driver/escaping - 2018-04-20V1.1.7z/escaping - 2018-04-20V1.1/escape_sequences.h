#pragma once

#include <string>

std::string replaceEscapeSequences(const std::string & query);
